/**
 * @file hacking_functions.cpp
 * @brief Provided Library for CPE Students for process manipulation and memory access.
 *
 * Provides detailed implementations of functions declared in hacking_functions.h
 * for manipulating and observing the state of a target process via ptrace.
 * 
 * Use this library in your assignment, hacker.cpp with #include "hacking_functions.h"
 * 
 * Compile command: g++ -o hacker hacker.cpp hacking_functions.cpp -std=c++11 && sudo ./hacker
 * Note : This tool uses ptrace, which may require running as root depending on system configuration.
 *
 * @author Pi Ko
 * @email pi.ko@nyu.edu
 * @date 2024-08-24
 */
/*-------------------------------------------------*/

#include "hacking_functions.h"
#include <iostream>
#include <fstream>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <cstdint> // Include for uintptr_t type

// Function to attach to the target process for debugging
bool attachToProcess(int target_pid)
{
    if (ptrace(PTRACE_ATTACH, static_cast<pid_t>(target_pid), nullptr, nullptr) == -1)
    {
        perror("Failed to attach to the target process.");
        return false;
    }
    waitpid(static_cast<pid_t>(target_pid), nullptr, 0); // Wait for the process to stop
    return true;
}

// Function to detach from the target process
void detachProcess(int target_pid)
{
    ptrace(PTRACE_DETACH, static_cast<pid_t>(target_pid), nullptr, nullptr); // Detach from the process
}

// Function to modify a memory value in the target process
bool modifyValue(int target_pid, long address_of_number, int new_value)
{
    if (ptrace(PTRACE_POKEDATA, static_cast<pid_t>(target_pid), reinterpret_cast<void *>(address_of_number), new_value) == -1)
    {
        perror("Failed to write to the target process's memory.");
        return false;
    }
    // Optional : For debuggin , log the modification details after successful modification
    // std::cout << "[Hack] Modified value at address " << std::hex << address_of_number << " to " << new_value << std::dec << std::endl;
    return true;
}

// Function to read a value at a specific address
int readValue(int target_pid, long address_of_number)
{
    errno = 0;
    long value = ptrace(PTRACE_PEEKDATA, static_cast<pid_t>(target_pid), reinterpret_cast<void *>(address_of_number), nullptr);
    if (value == -1 && errno != 0)
    {
        perror("Failed to read from the target process's memory.");
        return -1;
    }
    return static_cast<int>(value);
}

// Function implementations for UI character manipulation:

// Function to read a character from the target process memory
char readUIChar(int target_pid, long address)
{
    // Calculate the word-aligned address
    long aligned_address = address - (address % sizeof(long));

    // Read the long value at the aligned address
    errno = 0;
    long word = ptrace(PTRACE_PEEKDATA, static_cast<pid_t>(target_pid), reinterpret_cast<void *>(aligned_address), nullptr);
    if (word == -1 && errno != 0)
    {
        perror("Failed to read from the target process's memory.");
        return '\0';
    }

    // Extract the byte corresponding to the address
    unsigned char *word_ptr = (unsigned char *)&word;
    int byte_offset = address % sizeof(long); // Calculate the offset within the word
    return word_ptr[byte_offset];
}

// Function to write a character to the target process memory
bool writeUIChar(int target_pid, long address, char new_char)
{
    // Calculate the word-aligned address
    long aligned_address = address - (address % sizeof(long));

    // Read the long value at the aligned address
    errno = 0;
    long word = ptrace(PTRACE_PEEKDATA, static_cast<pid_t>(target_pid), reinterpret_cast<void *>(aligned_address), nullptr);
    if (word == -1 && errno != 0)
    {
        perror("Failed to read from the target process's memory.");
        return false;
    }

    // Modify the byte corresponding to the address
    unsigned char *word_ptr = (unsigned char *)&word;
    int byte_offset = address % sizeof(long);
    word_ptr[byte_offset] = new_char;

    // Write the modified long value back to the process memory
    if (ptrace(PTRACE_POKEDATA, static_cast<pid_t>(target_pid), reinterpret_cast<void *>(aligned_address), word) == -1)
    {
        perror("Failed to write to the target process's memory.");
        return false;
    }

    return true;
}