/**
 * @file hacking_functions.h
 * @brief Provided Library for CPE Students for process manipulation and memory access.
 *
 * This header file contains declarations for functions used to attach to,
 * detach from, modify memory of, and read memory from a target process.
 * These functions are essential for debugging and manipulating running processes.
 * 
 * Use this library in your assignment, hacker.cpp with #include "hacking_functions.h"
 * 
 * Compile command: g++ -o hacker hacker.cpp hacking_functions.cpp -std=c++11 && sudo ./hacker
 * Note : This tool uses ptrace, which may require running as root depending on system configuration.
 *
 * @author Pi Ko
 * @email pi.ko@nyu.edu
 * @date 2024-08-24
 */
/*-------------------------------------------------*/

#ifndef HACKING_FUNCTIONS_H
#define HACKING_FUNCTIONS_H

#include <sys/types.h> // Required for pid_t type
#include <cstdint>     // Include for uintptr_t type

// Attaches to the target process for debugging purposes.
bool attachToProcess(int target_pid);

// Detaches from the target process.
void detachProcess(int target_pid);

// Modifies a memory value in the target process.
bool modifyValue(int target_pid, long address_of_number, int new_value);

// Reads a value at a specific address in the target process.
int readValue(int target_pid, long address_of_number);

// New function declarations for UI character manipulation:

// Reads a character from a specific memory address in the target process.
char readUIChar(int target_pid, long address);

// Writes a character to a specific memory address in the target process.
bool writeUIChar(int target_pid, long address, char new_char);

#endif // HACKING_FUNCTIONS_H
